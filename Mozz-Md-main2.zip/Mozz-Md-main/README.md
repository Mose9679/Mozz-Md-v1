### *BEST MULTI-DEVICE WHATSAPP BOT *




</p>
</p>
<p align="center">
  <a href="https://chat.whatsapp.com/HPMkVXigXN44ZSJAqZ3dbY">
    <img alt=Support height="250" src="https://telegra.ph/file/1dc10a39146c80069a439.jpg"> 
    </p>
<h1 align="center">    MOZZ MD
</h1>
<p align="center"> 
    </p>


   [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=THANKYOU+FOR+CHOOSING+MOZZ+MD+MADE+BY;MOSE9679;THANKS+FOR+VISITING+MY+REPO)](https://git.io/typing-svg)



<p align="left">
  <a href="" target="_blank">
    <img alt="Forks" src="https://img.shields.io/github/forks/mose9679/mozz-md" />
  </a>
  
  

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{mose9679}/count.svg" alt="mose9679 :: Visitor's Count" /></p>
<p align="center">
 <a href="https://chat.whatsapp.com/HPMkVXigXN44ZSJAqZ3dbY" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ MOZZ-BOT Support Group -25D366?style=for-the-badge&logo=whatsapp&logoColor=blue" />
  </a>
</p>

---
***Scan QR Code***

1. ***Get [SESSION-ID](https://session-dnke.onrender.com/qr) by pairing code. `Whatapp>Three dots>Linked Devices****
2. . ***GET [PAIR CODE](https://chat.whatsapp.com/IIpL6gf6dcq4ial8gaJLE9) currently not working please use session id cause it works best***
--- 
 ***Fork Repo***
2. ***Click [FORK](https://github.com/mose9679/mozz-md/fork)***
 
---

JOIN THE GROUP TO GET MONGODB URI WHICH WILL HELP YOU TO RUN THE BOT
[GROUP](https://chat.whatsapp.com/IIpL6gf6dcq4ial8gaJLE9)

---

 ***NOW  DEPLOY IT.***
Deployments methods

 
<h4 align="left"> Deploy on Heroku
</h4>

</p>

<p align="left" >
    <a href="https://heroku.com/deploy?template=https://github.com/mose9679/mozz-md ">
    <img src="https://telegra.ph/file/873a73bb44e63d9598fa8.png" width="100px" alt="Deploy to Heroku" >
    </a>

</p> 

<br>
   


----

💻 ***MOZZ-MD DEVELOPER TEAM* *2024***
  
| [mose9679](https://github.com/mose9679) |
| Owner, Developer, Maintainer, updates|

| [TEAM MOZZA](https://chat.whatsapp.com/HPMkVXigXN44ZSJAqZ3dbY) |
| maintainer and helpers|


---
<a href="[https://github.com/mose9679.png]"><img src="https://github.com/mose9679.png" width="200" height="200" alt="Ash"/></a>
 </div>
<br>
<h4 align="left">

---

  </br> 
<h4 align="left">
##𝐒𝐮𝐩𝐩𝐨𝐫𝐭 :
    
 ***Tap On Logo To Contat Me***
 <p align="left">
  <a href="mosesnjau174@gmail.com">
    <img src="https://telegra.ph/file/84284eaa31d60db5f2d6c.jpg" align="centre" width="90" />
   <a href="https://wa.me/254769894118?text=Hi%20Mose%20Sir...%20I%20need%20some%20help%20in%20Mozz Bot">
    <img src="https://telegra.ph/file/aa1fd064edcf7c32cf42d.png" align="centre" width="90" />


<p align="left">
  <a aria-label="Join our chats" href="https://chat.whatsapp.com/HPMkVXigXN44ZSJAqZ3dbY" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Join Our Bot Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>



</br>

***MOZZ MD MORE UPDATE COMMING SOON....***

***FIXING MORE***

©Team Mozza
