Mozz md is a base bot from lazack md...

keep using  Mozz md don't forget to forkand give a star to Mozz Md


join the new group now

link given below;




https://chat.whatsapp.com/BhOVM6VPMwpDA9xIIf751L





━━━━━•❃°•°•━━━━━•❃

Hey 👋 users

> `📌 Feel free to deploy Mozz Md`

*⭐ Total Stars:* 0 stars

*🍽️ Forks:* 0 forks

*🍁 Repo:* https://github.com/Mose9679/Mozz-Md
*Group:* https://chat.whatsapp.com/BhOVM6VPMwpDA9xIIf751L

*public grp:* https://chat.whatsapp.com/BhOVM6VPMwpDA9xIIf751L

*scan Qr:* https://session-dnke.onrender.com/



*Deploy Your Own:*-
visit github Mozz-md for deployment method

*MONGODB_URI*

mongodb+srv://Maher:Zubair@sigma-male.ggwx4gc.mongodb.net/?retryWrites=true&w=majority
