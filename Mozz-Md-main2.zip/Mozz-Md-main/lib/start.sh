while true
do
echo "Starting suhail-md..."
node lib/client.js
done
