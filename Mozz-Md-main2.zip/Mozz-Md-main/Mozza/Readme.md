I'm still finding the best base to Mozz Md md

l
Mozz Md is still a simple and small project

base of this bot is lazack md,blade md, sector md and suhail md

credit to blade md 

credit to sector base

credit to lazack md

appreciate the team work from the following

     whizbot
     
     jflex
